# 仅私人交付，不随代码公开

skins：Ning Ning（紫）、Giselle（蓝）、Karina（灰）、Winter（白）四张精灵图。本任务没有获得独立公开授权证明，不为它们设置开源许可证。

videos/demo-with-user-music.mp4：用户指定的商业录音《KISS N TELL》片段，并包含 Aespa 官网宣传图与榜单界面。仅作为此次用户交付，不代表已获 GitHub 或其他平台公开上传许可。

videos/demo-muted-reduced-media.mp4：没有音频轨，已移除官网照片轮播与榜单数据段；仍包含上述角色和应用界面，因此不是“全面版权安全”证明。

不要把本目录、整包 ZIP、生成应用或复制后的 assets-local/ 强制加入公开仓库。取得必要授权或替换素材后，另行决定公开版本。

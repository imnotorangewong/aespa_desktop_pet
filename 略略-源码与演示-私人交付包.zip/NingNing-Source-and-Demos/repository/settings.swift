import AppKit

// Derive the menu icon only from the existing first idle frame; retain original colors/alpha.
enum PetMenuIcon {
    static let settings:NSImage? = {
        guard let icon=NSImage(systemSymbolName:"gearshape",accessibilityDescription:"设置")?.withSymbolConfiguration(NSImage.SymbolConfiguration(pointSize:14,weight:.regular)) else{return nil}
        icon.size=NSSize(width:16,height:16);icon.isTemplate=true;return icon
    }()
    static var restart:NSImage? {makeRestart(sheet:(NSApp.delegate as? AppDelegate)?.skins.current?.sheet)}
    static func makeRestart(sheet selected:CGImage?)->NSImage? {
        guard let url=Bundle.main.url(forResource:"spritesheet-clean",withExtension:"png"),let source=NSImage(contentsOf:url),let fallback=source.cgImage(forProposedRect:nil,context:nil,hints:nil),let frame=(selected ?? fallback).cropping(to:CGRect(x:0,y:0,width:192,height:208)) else{return nil}
        let bitmap=NSBitmapImageRep(cgImage:frame);var minX=192,minY=208,maxX = -1,maxY = -1
        for y in 0..<208 {for x in 0..<192 {if (bitmap.colorAt(x:x,y:y)?.alphaComponent ?? 0)>0.01 {minX=min(minX,x);minY=min(minY,y);maxX=max(maxX,x);maxY=max(maxY,y)}}}
        guard maxX>=minX,maxY>=minY,let cropped=frame.cropping(to:CGRect(x:minX,y:minY,width:maxX-minX+1,height:maxY-minY+1)),let context=CGContext(data:nil,width:32,height:32,bitsPerComponent:8,bytesPerRow:128,space:CGColorSpaceCreateDeviceRGB(),bitmapInfo:CGImageAlphaInfo.premultipliedLast.rawValue) else{return nil}
        let scale=28.0/Double(max(cropped.width,cropped.height));let w=Double(cropped.width)*scale,h=Double(cropped.height)*scale
        context.interpolationQuality = .high;context.draw(cropped,in:CGRect(x:(32-w)/2,y:(32-h)/2,width:w,height:h))
        guard let result=context.makeImage() else{return nil};let icon=NSImage(cgImage:result,size:NSSize(width:16,height:16));icon.isTemplate=false;return icon
    }
}

enum PetFeature:String,CaseIterable {
    case chat,news,rank,music,gallery
    var title:String {switch self{case .chat:return "聊天";case .news:return "同济news";case .rank:return "AI rank";case .music:return "Music Calendar";case .gallery:return "Aespa"}}
    var action:Selector {switch self{case .chat:return #selector(AppDelegate.showChat);case .news:return #selector(AppDelegate.showNews);case .rank:return #selector(AppDelegate.showRank);case .music:return #selector(AppDelegate.showMusic);case .gallery:return #selector(AppDelegate.showGallery)}}
}
struct PetMenuConfig:Codable,Equatable {
    var order:[String]=PetFeature.allCases.map{$0.rawValue}
    var hidden:[String]=[]
    func normalized(registryIDs:[String]=PetFeature.allCases.map{$0.rawValue})->PetMenuConfig {
        let known=Set(registryIDs);var seen=Set<String>()
        let complete=(order+registryIDs).filter{known.contains($0) && seen.insert($0).inserted}
        return PetMenuConfig(order:complete,hidden:registryIDs.filter{hidden.contains($0)})
    }
}
final class PetMenuPreferences {
    static let key="pet.menu.preferences.v1"
    private let defaults:UserDefaults
    private(set) var config=PetMenuConfig()
    init(defaults:UserDefaults = .standard){self.defaults=defaults;if let data=defaults.data(forKey:Self.key),data.count<=4096,let saved=try? JSONDecoder().decode(PetMenuConfig.self,from:data){config=saved.normalized()}}
    private func save(){config=config.normalized();if let data=try? JSONEncoder().encode(config){defaults.set(data,forKey:Self.key)}}
    func setVisible(_ visible:Bool,feature:String){guard PetFeature(rawValue:feature) != nil else{return};config.hidden.removeAll{$0==feature};if !visible{config.hidden.append(feature)};save()}
    func move(_ feature:String,by offset:Int){guard abs(offset)==1,let index=config.order.firstIndex(of:feature),config.order.indices.contains(index+offset) else{return};config.order.swapAt(index,index+offset);save()}
    func menu(target:AnyObject?)->NSMenu {
        let menu=NSMenu()
        for id in config.order where !config.hidden.contains(id){guard let feature=PetFeature(rawValue:id) else{continue};let item=NSMenuItem(title:feature.title,action:feature.action,keyEquivalent:"");item.target=target;menu.addItem(item)}
        if !menu.items.isEmpty{menu.addItem(.separator())}
        let settings=NSMenuItem(title:"设置",action:#selector(AppDelegate.showSettings),keyEquivalent:"");settings.target=target;settings.image=PetMenuIcon.settings;menu.addItem(settings)
        let quit=NSMenuItem(title:"退出桌宠",action:#selector(NSApplication.terminate(_:)),keyEquivalent:"");quit.target=NSApp;menu.addItem(quit)
        let restart=NSMenuItem(title:"重启桌宠",action:#selector(AppDelegate.restartPet),keyEquivalent:"");restart.target=target;restart.image=PetMenuIcon.restart;restart.toolTip="清空本次聊天并重新打开此位置的最新版";menu.addItem(restart)
        return menu
    }
}
final class PetSettingsController:NSObject {
    let skinPicker=NSPopUpButton();let skins:PetSkinStore;let onSkinChange:(LoadedPetSkin)->Bool
    let panel:ChatPanel;let owner:NSWindow;let preferences:PetMenuPreferences
    let rows=NSView(frame:NSRect(x:20,y:72,width:390,height:250))
    init(owner:NSWindow,preferences:PetMenuPreferences,skins:PetSkinStore=PetSkinStore(),onSkinChange:@escaping(LoadedPetSkin)->Bool={_ in false}){
        self.skins=skins;self.onSkinChange=onSkinChange;self.owner=owner;self.preferences=preferences;panel=ChatPanel(contentRect:NSRect(x:0,y:0,width:430,height:410),styleMask:[.borderless],backing:.buffered,defer:false);super.init()
        panel.title="桌宠设置";panel.isOpaque=false;panel.backgroundColor = .clear;panel.hasShadow=true;panel.level = .floating;panel.hidesOnDeactivate=false;panel.collectionBehavior=[.canJoinAllSpaces,.fullScreenAuxiliary]
        let content=DragBackgroundView(frame:NSRect(x:0,y:0,width:430,height:410))
        if #available(macOS 26,*){let glass=NSGlassEffectView(frame:content.bounds);glass.cornerRadius=26;glass.contentView=content;panel.contentView=glass}else{let glass=NSVisualEffectView(frame:content.bounds);glass.material = .popover;glass.state = .active;glass.addSubview(content);panel.contentView=glass}
        let title=NSTextField(labelWithString:"设置");title.font = .systemFont(ofSize:20,weight:.semibold);title.frame=NSRect(x:24,y:360,width:250,height:30);content.addSubview(title)
        let close=NSButton(title:"×",target:self,action:#selector(hide));close.frame=NSRect(x:378,y:360,width:28,height:28);close.setAccessibilityLabel("关闭设置");content.addSubview(close)
        let scroll=NSScrollView(frame:rows.frame);scroll.hasVerticalScroller=true;scroll.drawsBackground=false;rows.setFrameOrigin(.zero);scroll.documentView=rows;content.addSubview(scroll)
        let skinLabel=NSTextField(labelWithString:"皮肤");skinLabel.frame=NSRect(x:24,y:29,width:48,height:22);content.addSubview(skinLabel)
        skinPicker.frame=NSRect(x:80,y:24,width:326,height:30);skinPicker.target=self;skinPicker.action=#selector(changeSkin);content.addSubview(skinPicker)
        render()
    }
    func render(){skinPicker.removeAllItems();skinPicker.addItems(withTitles:skins.available.map{$0.descriptor.title});if let i=skins.available.firstIndex(where:{$0.descriptor.id==skins.selectedID}){skinPicker.selectItem(at:i)};skinPicker.isEnabled = !skins.available.isEmpty;rows.subviews.forEach{$0.removeFromSuperview()};rows.setFrameSize(NSSize(width:390,height:max(250,preferences.config.order.count*48)));for (index,id) in preferences.config.order.enumerated(){guard let feature=PetFeature(rawValue:id) else{continue};let y=rows.bounds.height-CGFloat(index+1)*48
        let toggle=NSButton(checkboxWithTitle:feature.title,target:self,action:#selector(toggleFeature(_:)));toggle.frame=NSRect(x:4,y:y+6,width:260,height:30);toggle.tag=index;toggle.state=preferences.config.hidden.contains(id) ? .off:.on;rows.addSubview(toggle)
        for (delta,x,label) in [(-1,CGFloat(280),"↑"),(1,CGFloat(332),"↓")]{let button=NSButton(title:label,target:self,action:delta<0 ? #selector(moveUp(_:)):#selector(moveDown(_:)));button.frame=NSRect(x:x,y:y+6,width:44,height:30);button.tag=index;button.isEnabled=preferences.config.order.indices.contains(index+delta);button.setAccessibilityLabel("\(feature.title)\(delta<0 ? "上移":"下移")");rows.addSubview(button)}
    }}
    @objc func changeSkin(){let index=skinPicker.indexOfSelectedItem;guard skins.available.indices.contains(index) else{return};if !skins.select(skins.available[index].descriptor.id,apply:onSkinChange){let alert=NSAlert();alert.messageText="此皮肤暂时无法应用";alert.informativeText="保留当前皮肤，请检查素材是否完整。";alert.runModal()};render()}
    @objc func toggleFeature(_ sender:NSButton){guard preferences.config.order.indices.contains(sender.tag) else{return};preferences.setVisible(sender.state == .on,feature:preferences.config.order[sender.tag]);render()}
    private func move(_ sender:NSButton,_ delta:Int){guard preferences.config.order.indices.contains(sender.tag) else{return};preferences.move(preferences.config.order[sender.tag],by:delta);render()}
    @objc func moveUp(_ sender:NSButton){move(sender,-1)}
    @objc func moveDown(_ sender:NSButton){move(sender,1)}
    @objc func hide(){panel.orderOut(nil)}
    func show(){let s=(owner.screen ?? NSScreen.main)!.visibleFrame;panel.setFrameOrigin(NSPoint(x:max(s.minX,min(owner.frame.midX-215,s.maxX-430)),y:max(s.minY,min(owner.frame.maxY-8,s.maxY-410))));render();panel.makeKeyAndOrderFront(nil);NSApp.activate(ignoringOtherApps:true)}
}
func petSettingsSelfTest(){
    precondition(PetMenuIcon.settings != nil && PetMenuIcon.settings!.size==NSSize(width:16,height:16) && PetMenuIcon.settings!.isTemplate)
    let suite="pet-menu-test-"+UUID().uuidString;let defaults=UserDefaults(suiteName:suite)!;defer{defaults.removePersistentDomain(forName:suite)}
    defaults.set(Data("invalid".utf8),forKey:PetMenuPreferences.key);precondition(PetMenuPreferences(defaults:defaults).config==PetMenuConfig())
    defaults.set(try! JSONEncoder().encode(PetMenuConfig(order:["gallery","bogus","gallery"],hidden:["chat","bogus","chat"])),forKey:PetMenuPreferences.key)
    let old=PetMenuConfig(order:["gallery","chat","gallery","retired"],hidden:["chat","retired"])
    let migrated=old.normalized(registryIDs:PetFeature.allCases.map{$0.rawValue}+["futureFeature"])
    precondition(migrated.order==["gallery","chat","news","rank","music","futureFeature"] && migrated.hidden==["chat"])
    precondition(migrated.normalized(registryIDs:PetFeature.allCases.map{$0.rawValue}+["futureFeature"])==migrated)
    let p=PetMenuPreferences(defaults:defaults);precondition(p.config.order==["gallery","chat","news","rank","music"] && p.config.hidden==["chat"])
    p.move("gallery",by:1);p.setVisible(true,feature:"chat");p.setVisible(false,feature:"music")
    precondition(PetMenuPreferences(defaults:defaults).config==p.config)
    let before=p.config;p.move("chat",by:-1);p.move("music",by:1);p.move("bogus",by:1);precondition(p.config==before)
    let menu=p.menu(target:nil)
    let icon=menu.items.last!.image!;precondition(icon.size==NSSize(width:16,height:16) && !icon.isTemplate)
    let preview=NSBitmapImageRep(data:icon.tiffRepresentation!)!;precondition(preview.pixelsWide==32 && preview.pixelsHigh==32)
    precondition((preview.colorAt(x:0,y:0)?.alphaComponent ?? 1)==0)
    try! preview.representation(using:.png,properties:[:])!.write(to:URL(fileURLWithPath:"/tmp/pet-restart-menu-icon.png"))
    print("PASS: restart icon first idle frame, 16pt/32px, original color and transparent corner")
    precondition(menu.items.filter{!$0.isSeparatorItem}.map{$0.title}==["聊天","Aespa","同济news","AI rank","设置","退出桌宠","重启桌宠"])
    for f in PetFeature.allCases{p.setVisible(false,feature:f.rawValue)}
    precondition(p.menu(target:nil).items.map{$0.title}==["设置","退出桌宠","重启桌宠"])
    let owner=NSWindow(contentRect:NSRect(x:0,y:0,width:100,height:100),styleMask:[.borderless],backing:.buffered,defer:false)
    let settings=PetSettingsController(owner:owner,preferences:p);precondition(settings.rows.subviews.count==15)
    let toggle=settings.rows.subviews.compactMap{$0 as? NSButton}.first!;toggle.state = .on;settings.toggleFeature(toggle);precondition(!p.config.hidden.contains(p.config.order[0]));settings.hide();settings.render();precondition(settings.rows.subviews.count==15)
    print("PASS: menu preferences corrupt fallback, normalized complete order, reload/new-feature migration, boundaries, all-hidden fixed actions, settings controls; no service lifecycle calls")
}
